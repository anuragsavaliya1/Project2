import homeIcon from "../assets/home.svg";

const home = { homeIcon };
